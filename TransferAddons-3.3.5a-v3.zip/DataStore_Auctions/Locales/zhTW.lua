﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Auctions", "zhTW" )

if not L then return end


