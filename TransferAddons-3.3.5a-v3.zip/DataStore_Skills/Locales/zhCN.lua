﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Skills", "zhCN" )

if not L then return end

L["Professions"] = "专业"
L["Secondary Skills"] = "辅助技能"
L["Riding"] = "骑术"
