local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Quests", "ruRU" )

if not L then return end


