local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Quests", "deDE" )

if not L then return end


